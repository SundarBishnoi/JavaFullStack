Q 1.1


SQL> DECLARE
  2  V_Sample1 NUMBER(2);
  3  V_Sample2 CONSTANT NUMBER(2) ;
  4  V_Sample3 NUMBER(2) NOT NULL ;
  5  V_Sample4 NUMBER(2) := 50;
  6  V_Sample5 NUMBER(2) DEFAULT 25;
  7  /
V_Sample5 NUMBER(2) DEFAULT 25;
                              *
ERROR at line 6:
ORA-06550: line 6, column 31:
PLS-00103: Encountered the symbol "end-of-file" when expecting one of the
following:
begin function pragma procedure subtype type <an identifier>
<a double-quoted delimited-identifier> current cursor delete
exists prior

====================================================================================
--------------------------------------------------------------------------
Q 1.2.
<<OUTER_BLOCK>>
DECLARE 
var_num1 NUMBER := 5;
BEGIN
<<INNER_BLOCK>>
DECLARE 
var_num1 NUMBER := 10;
BEGIN
DBMS_OUTPUT.PUT_LINE('Value for var_num1:' ||var_num1);
DBMS_OUTPUT.PUT_LINE('Value for outer var_num1:' ||OUTER_BLOCK.var_num1);
END;

END;
--Inner block refernce is out of scope from outer block.

====================================
Q 1.3

DECLARE
	empRecord	emp%ROWTYPE;
BEGIN
	SELECT * INTO empRecord from emp
		where empno=7369;
	DBMS_OUTPUT.PUT_LINE(empRecord.empno||' '||empRecord.ename);
EXCEPTION
	WHEN NO_DATA_FOUND
	THEN DBMS_OUTPUT.PUT_LINE('NO SUCH DATA');
end;	

==================
Q 1.4

DECLARE
	scode	Staff_Master.staff_code%type;
	sname Staff_Master.staff_name%type;
	dname department_master.dept_name%type;
BEGIN
	SELECT staff_name,staff_code,dept_name INTO sname, scode,dname from Staff_Master s,department_master d
		where staff_name='&ename' and s.dept_code=d.dept_code;
	DBMS_OUTPUT.PUT_LINE(sname||' '||scode|| ' '||dname);
EXCEPTION
	WHEN NO_DATA_FOUND
	THEN DBMS_OUTPUT.PUT_LINE('NO SUCH DATA');
end;
/

==============================
Q 1.5
DECLARE
	salary employee.sal%TYPE;
	deptid employee.deptno%TYPE:=&id;
BEGIN
	SELECT sal INTO salary 
		FROM employee
			WHERE deptno=deptid;
			
	IF salary*0.3>5000
	THEN
		UPDATE employee
		SET sal=sal+5000
		WHERE deptno=deptid;
	ELSE
		UPDATE employee
		SET sal=sal+sal*0.3
		WHERE deptno=deptid;
	END IF;
END;
/

=====================LAB 2=========================
2.1

DECLARE
V_BONUS STAFF_MASTER.STAFF_SAL%TYPE;
V_SAL STAFF_MASTER.STAFF_SAL%TYPE;
CURSOR c_sal IS SELECT staff_sal FROM staff_master where mgr_code=100006;
BEGIN
if c_sal%ISOPEN
	then
		null;
	else
		OPEN c_sal;
	end if;
	FETCH c_sal into v_sal;
	LOOP
		FETCH c_sal into v_sal;
		exit when c_sal%NOTFOUND;
		V_BONUS:=2*V_SAL;
		DBMS_OUTPUT.PUT_LINE('STAFF SALARY IS ' || V_SAL);
		DBMS_OUTPUT.PUT_LINE('STAFF BONUS IS ' || V_BONUS);
	end loop;
EXCEPTION
WHEN NO_DATA_FOUND THEN
DBMS_OUTPUT.PUT_LINE('GIVEN CODE IS NOT VALID.ENTER VALID CODE');
END;

-------------
Q 2.2
Same as 2.1


QUE- 2.3:
 
declare 
commission emp.comm%type;
 
begin
 
select comm into commission from emp where empid=7369;
 
if commission = null
then
raise no_data_found;
 
else 
dbms_output.put_line('the commission is:' commission);
end if;
 
exception
when no_data_found then 
dbms_output.put_line('NO COMMISSINON WAS FOUND');
 
end;

========================LAB 3==========

Q 3.1

 CREATE OR REPLACE FUNCTION FINDAGE(
 DT IN date)
 RETURN NUMBER IS
 AGE NUMBER;
 BEGIN
 AGE:= ROUND((SYSDATE - DT)/365);
 RETURN AGE;
 END;
/
--
select findage('13-MAY-93') from dual
--
begin
	DBMS_OUTPUT.PUT_LINE(FINDAGE('12-May-1993'));
end;
---------------------------
Q 3.2

create or replace procedure findMGR
(
SNo in staff_master.staff_code%type,
SId out staff_master.staff_code%type,
SName out staff_master.staff_name%type,
DCode out staff_master.dept_code%type,
MName out staff_master.staff_name%type
)
as 
BEGIN
    select a.staff_code,a.staff_name,a.dept_code,b.staff_name as manager into SId,SName,DCode,MName 
    from  staff_master a,staff_master b 
    where a.mgr_code=b.staff_code and a.staff_code = SNo;
    if(sql%notfound) then
        raise no_data_found;
    end if;   
    exception
        when no_data_found then
            dbms_output.put_line('staff code not found');
end;
-------
declare
SId  staff_master.staff_code%type;
SName  staff_master.staff_name%type;
DCode  staff_master.dept_code%type;
MName  staff_master.staff_name%type;
begin
	findMGR(100002,SId,SName,DCode,MName);
	dbms_output.put_line(SId||' '||SName||' '||DCode||' '||MName);
end;
=============================
Q 3.3

create or replace function CostToComp(code in number) return number
is
    sal staff_master.staff_sal%type;
    exp number;
BEGIN
    select staff_sal,round(months_between(sysdate,hiredate)/12) as EXP into sal, exp from staff_master where staff_code=code;
    if exp>4 then
    sal:=sal+ (0.3*sal)+(0.15*sal)+(0.2*sal)+(0.08*sal);
    elsif exp between 2 and 4 then
    sal:=sal+ (0.2*sal)+(0.15*sal)+(0.2*sal)+(0.08*sal);
    elsif exp between 1 and 2 then
    sal:=sal+ (0.1*sal)+(0.15*sal)+(0.2*sal)+(0.08*sal);
    else 
    sal:=sal+(0.15*sal)+(0.2*sal)+(0.08*sal);
    end if;
    return sal;
end;
 
 
DECLARE 
    CALC_SAL NUMBER;
BEGIN
    CALC_SAL:=CostToComp(&staff_code);
    dbms_output.put_line(CALC_SAL);
END;
-------------------
Q 3.4
CREATE TABLE STAFF_MASTERS_BACK AS(SELECT * FROM STAFF_MASTER);
TRUNCATE TABLE STAFF_MASTERS_BACK;


create or replace procedure staff_backup(s_code in staff_master.staff_code%type)
    is
    exp number;
    v_sal staff_master.staff_sal%type;
BEGIN
    insert into staff_masters_back(select * from staff_master where staff_code=s_code);
    select staff_sal, round(months_between(sysdate,hiredate)/12) 
	into v_sal, exp from staff_master where staff_code=s_code;
 
    if v_sal IS NULL THEN
	RAISE NO_DATA_FOUND;
 
    if exp>5 then
    	v_sal := (1.25 * v_sal);
    end if;
    if exp between 2 and 5 then
    	v_sal:= (1.20 * v_sal);
    end if;
    update staff_masters set staff_sal=v_sal;
	EXCEPTION
		WHEN NO_DATA_FOUND THEN
			DBMS_OUTPUT.PUT_LINE("NO DATA FOUND! PLS VERIFY");
end;
----------------
Q 3.5

create or replace procedure insertrecords
	(bcode in book_transactions.book_code%type,
	code in number
)
as
	code1 number;
	exc exception;
	doe varchar2(50);
	doe1 date;
	cursor mycur1 is 
	select staff_code from staff_master where staff_code=code;
	cursor mycur2 is 
	select student_code from student_master where student_code=code;
begin 
	select to_char(sysdate+10,'DAY') INTO doe FROM DUAL;
	if(doe='SATURDAY') then
		select (sysdate+12) INTO doe1 FROM DUAL;
	elsif (doe='SUNDAY')then
		select (sysdate+11) INTO doe1 FROM DUAL;
	else
		select (sysdate+10) INTO doe1 FROM DUAL;
	end if;
	open mycur1;
	open mycur2;
	loop
		fetch mycur1 into code1;
		if(mycur1%notfound and mycur1%rowcount=0) then
			fetch mycur2 into code1;
			if(mycur2%notfound and mycur2%rowcount=0) then
				raise exc;
			else
				exit when(mycur2%notfound);
				insert into book_transactions values(bcode,code1,null,sysdate,doe1,null);
			end if; 
		else
			exit when(mycur1%notfound);
			insert into book_transactions values(bcode,null,code1,sysdate,doe1,null);
		end if;
	end loop;
exception
	when exc then
	dbms_output.put_line('not found');
end;
/
show error;
delete from  book_transactions where book_issue_date LIKE '%07-OCT-17%';
 
execute insertrecords(10000007,100002);
execute insertrecords('10000002','1015'); 

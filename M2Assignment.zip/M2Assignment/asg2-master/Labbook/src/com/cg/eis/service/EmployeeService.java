package com.cg.eis.service;


//5.1: com.cg.eis.service: This package will contain code for services offered in Employee Insurance System. The service class will have one EmployeeService Interface and its corresponding implementation class.
public interface EmployeeService {
	public abstract String findScheme(Double salary, String designation);
	

}

package com.capgemini.lab11;

public class PoweerTest11_1 {

	public static void main(String[] args) {
		Power11_1 p=(x,y)-> Math.pow(x,y);
		double result=p.power(3, 2);
		System.out.println(result);
	}

}

package com.capgemini.lab11;

public class StringFormat11_2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String11_2 s=str->str.replaceAll("","").trim();
		String results=s.stringFormat("CG");
		System.out.println(results);

	}

}

package com.capgemini.lab11;

public interface String11_2 {
public abstract String stringFormat(String str);
}

package com.capgemini.lab11;

public interface LambdaInterface11_5 {
	public abstract void fact(int n);
}

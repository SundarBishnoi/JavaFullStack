package com.capgemini.lab11;

public interface LambdaInterface11_3 {

	public abstract boolean validation(String username,String password);
}

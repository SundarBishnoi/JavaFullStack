package com.capgemini.lab11;

public interface Power11_1 {

	public abstract double power(double x,double y);
}
	
package com.capgemini.lab11;

public interface Lab11_4Interface {

	public abstract Lab11_4main getlab11_4main(int id,String name, int age);
	
}

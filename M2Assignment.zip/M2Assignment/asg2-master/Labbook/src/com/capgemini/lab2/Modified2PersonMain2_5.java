package com.capgemini.lab2;

public class Modified2PersonMain2_5 {
	public static void main(String[] args) {
		ModifiedPerson2_4 p=new ModifiedPerson2_4("Abhilasha","Sawnerkar",'f',9579605747L);
		System.out.println("Person Details");
		System.out.println("----------------");
		System.out.println("First Name: "+p.getFirstName());
		System.out.println("Last Name: "+p.getLastName());
		System.out.println("Gender: "+p.getGender());
		System.out.println("Phonenumber: "+p.getPhonenumber());
	}


}

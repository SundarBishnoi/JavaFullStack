package com.capgemini.lab2;

public class PersonDetails2_1 {

	//2.1 Write a java program to print person details
	public static void main(String[] args) {
		System.out.println("Person Details");
		System.out.println("----------------");
		System.out.println("First Name:Divya\nLast Name:Bharti\nGender:F\nAge:20\nWeight:85.5");
		
	}

}

package com.capgemini.lab4;

public class Person {
	String name;
	float age;
	
	
	public Person(String name, float age) {
		super();
		this.age=age;
		this.name=name;
		
	}
	public Person() {
		super();// TODO Auto-generated constructor stub
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public float getAge() {
		return age;
	}
	public void setAge(float age) {
		this.age = age;
	}
	@Override
	public String toString() {
		return "Person [name=" + name + ", age=" + age + "]";
	
}
}
package com.capgemini.lab5_3;
//5.3: Refer the problem statement 4.1. Modify account class as abstract class and declare withdraw method.
public abstract class Account {
	public abstract void withdraw(double amount);

}

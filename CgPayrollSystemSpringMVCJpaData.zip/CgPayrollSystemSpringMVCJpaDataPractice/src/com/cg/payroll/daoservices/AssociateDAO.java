package com.cg.payroll.daoservices;
import java.util.ArrayList;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import com.cg.payroll.beans.Associate;
public interface AssociateDAO extends JpaRepository<Associate, Integer>{
	@org.springframework.data.jpa.repository.Query("select a from Associate a where a.yearlyInvestmentUnder80C<= :yearlyInvestmentUnder80C")
	public ArrayList<Associate> findFewAssociate(@Param("yearlyInvestmentUnder80C") double yearlyInvestmentUnder80C) ;

}

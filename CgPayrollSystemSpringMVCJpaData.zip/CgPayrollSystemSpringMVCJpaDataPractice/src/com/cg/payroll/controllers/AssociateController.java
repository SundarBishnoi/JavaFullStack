package com.cg.payroll.controllers;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import com.cg.payroll.beans.Associate;
import com.cg.payroll.exceptions.AssociateDetailNotFoundException;
import com.cg.payroll.exceptions.PayrollServicesDownException;
import com.cg.payroll.services.PayrollServices;
@Controller
public class AssociateController {
	@Autowired
	private PayrollServices payrollServices;
	@RequestMapping("/registerAssociate")
	public ModelAndView registerAssociateAction(@Valid@ModelAttribute Associate associate,BindingResult result) throws PayrollServicesDownException {
		if(result.hasErrors())
			return new ModelAndView("registrationPage");
		associate=payrollServices.acceptAssociateDetails(associate);
		return new ModelAndView("registrationSuccessPage", "associate", associate);
	}
	
	
	@RequestMapping(value="/associateDetails" ,method = RequestMethod.POST)
	public ModelAndView getAssociateAction(@RequestParam("associateID") int associateID) throws AssociateDetailNotFoundException, PayrollServicesDownException {
		Associate associate=payrollServices.getAssociateDetails(associateID);
		return new ModelAndView("associateDetailsPage","associate",associate);
	}
	
	@RequestMapping(value="/calculateNetSalary" ,method = RequestMethod.POST)
	public ModelAndView getNetSalaryAction(@RequestParam("associateID") int associateID) throws AssociateDetailNotFoundException, PayrollServicesDownException {
		double basicSalary=payrollServices.calculateNetSalary(associateID);
		return new ModelAndView("indexPage","basicSalary",basicSalary);
	}
}

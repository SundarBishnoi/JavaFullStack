package com.cg.project.exceptions;

public class PhotoStorageException extends Exception{
	public PhotoStorageException(String string) {
		
	}
}

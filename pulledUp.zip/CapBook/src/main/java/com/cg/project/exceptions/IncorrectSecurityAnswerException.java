package com.cg.project.exceptions;

public class IncorrectSecurityAnswerException extends Exception{
public IncorrectSecurityAnswerException(String string) {
		
	}
}

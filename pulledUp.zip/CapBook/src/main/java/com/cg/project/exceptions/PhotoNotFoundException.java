package com.cg.project.exceptions;

public class PhotoNotFoundException extends Exception{
	public PhotoNotFoundException(String string) {
		
	}
}

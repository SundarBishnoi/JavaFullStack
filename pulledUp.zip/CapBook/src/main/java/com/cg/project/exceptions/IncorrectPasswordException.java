package com.cg.project.exceptions;

public class IncorrectPasswordException extends Exception{
	public IncorrectPasswordException(String string) {
		// TODO Auto-generated constructor stub
	}
}

package com.cg.project.exceptions;

public class RelationDetailsNotFoundException extends Exception {
	
	public RelationDetailsNotFoundException(String string) {
		// TODO Auto-generated constructor stub
	}

}
